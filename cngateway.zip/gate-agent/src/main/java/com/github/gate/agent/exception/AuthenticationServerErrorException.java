package com.github.gate.agent.exception;

/**
 * luozhonghua on 2017/7/5.
 */
public class AuthenticationServerErrorException extends RuntimeException {
    public AuthenticationServerErrorException(String message) {
        super(message);
    }
}
