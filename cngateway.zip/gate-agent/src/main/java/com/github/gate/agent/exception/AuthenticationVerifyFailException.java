package com.github.gate.agent.exception;

/**
 * luozhonghua on 2017/7/5.
 */
public class AuthenticationVerifyFailException extends RuntimeException {
    public AuthenticationVerifyFailException(String message) {
        super(message);
    }
}
