package com.github.gate.back.service;

/**
 * Created by luozhonghua on 2018/5/2.
 */
public interface CacheLoadable<T> {

  public T load();

}
