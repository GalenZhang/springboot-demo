package com.github.gate.back.mapper;

import com.github.gate.back.entity.GroupType;
import tk.mybatis.mapper.common.Mapper;

public interface GroupTypeMapper extends Mapper<GroupType> {
}