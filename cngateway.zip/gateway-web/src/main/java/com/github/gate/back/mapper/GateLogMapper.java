package com.github.gate.back.mapper;

import com.github.gate.back.entity.GateLog;
import tk.mybatis.mapper.common.Mapper;

public interface GateLogMapper extends Mapper<GateLog> {
}