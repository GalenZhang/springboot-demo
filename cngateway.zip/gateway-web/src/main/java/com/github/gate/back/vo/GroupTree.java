package com.github.gate.back.vo;

import com.github.gate.common.vo.TreeNode;

/**
 * ${DESCRIPTION}
 *
 * @author luozhonghua
 * @create 2017-06-17 15:21
 */
public class GroupTree extends TreeNode {
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
